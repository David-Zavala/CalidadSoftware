# Uso del programa
Abrir terminal y asegúrese de que esta en el directorio del archivo a ejecutar.<br>
Luego ejecute 'python 1prg_p0.py'<br>
En caso de utilizar Python 3 ejecute 'python3 1prg_p0.py'<br>

### Los siguientes archivos, son copias de los archivos que realmente se utilizan, ya que si el nombre comienza con un número, los imports en python no funcionaban:
- 1prg_CheckMethods.py
- 1prg_Code.py

### Los archivos originales, que son los que el Programa1 realmente utiliza están respectivamente en:
- methods/CheckMethods.py
- classes/Code.py

### Todo esto con el fin de que existan los archivos con el prefijo '1prg_', como se pide en la bandeja de entrega.